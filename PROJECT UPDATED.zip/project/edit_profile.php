<?php
// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'project');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch 'id1' from the URL
$id1 = isset($_GET['id1']) ? $_GET['id1'] : null;

if ($id1) {
    // Fetch the user data based on 'id1'
    $sql = "SELECT * FROM users WHERE id1 = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id1); // Bind the 'id1' as an integer
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user is found
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        echo "User not found.";
        exit;
    }
    $stmt->close();

    // Update the user information when Save is clicked
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Get the updated values from the form
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Update the user in the database
        $update_sql = "UPDATE users SET first_name=?, last_name=?, phone=?, email=?, password=? WHERE id1=?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("sssssi", $first_name, $last_name, $phone, $email, $password, $id1);

        if ($stmt->execute()) {
            echo "<script>alert('Profile updated successfully!');</script>";
            // Redirect to profile page with id1
            echo "<script>window.location.href = 'profile.php?id1=$id1';</script>";
        } else {
            echo "Error updating record: " . $conn->error;
        }
        $stmt->close();
    }
} else {
    echo "No user ID provided.";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: linear-gradient(to right, #d9e4f5, #f1e3e6);
            font-family: Arial, sans-serif;
        }
        .form-box {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 30px;
            width: 350px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
            position: relative;
            text-align: center;
        }
        .icons {
            position: absolute;
            top: 15px;
            left: 15px;
        }
        .icons img {
            width: 25px;
            height: 25px;
            margin: 5px;
            cursor: pointer;
        }
        h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            background-color: #eeeeee;
            color: #333;
            text-align: center;
        }
        button {
            padding: 10px 20px;
            background-color: #ff4d4d;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            font-weight: bold;
        }
        button:hover {
            background-color: #e04444;
        }
        .back-button {
            position: absolute;
            top: 20px; /* Positioned at the top-left of the container */
            left: 20px;
            width: 50px; /* Increased size */
            height: 50px; /* Increased size */
            cursor: pointer;
            position: fixed;
        }

        .back-button img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        /* Tooltip styling */
        .back-button:hover::after {
            content: "Go Back";
            position: absolute;
            top: 60px; /* Below the button */
            left: 50%;
            transform: translateX(-50%);
            background-color: #000;
            color: #fff;
            padding: 5px 10px;
            font-size: 12px;
            border-radius: 5px;
            white-space: nowrap;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }
        footer {
            background-color: #000;
            color: #fff;
            text-align: center;
            padding: 3px;
            width: 100%;
            position: fixed;
            bottom: 0;
            left: 0;
            box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.2);
        }

        footer p {
            font-size: 14px;
            margin: 0;
        }
        header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 5px;
    background-color: #1e1e1e;
    color: white;
    width: 100%;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
}

.back-button {
    margin-top:-10px;
    position: relative;
    cursor: pointer;
}

.back-button img {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

/* Tooltip for Back Button */
.back-button:hover::after {
    content: "Go Back";
    position: absolute;
    top: 50px;
    left: 50%;
    transform: translateX(-50%);
    background-color: #000;
    color: #fff;
    padding: 5px 10px;
    font-size: 12px;
    border-radius: 5px;
    white-space: nowrap;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    z-index: 1000;
}

.title-container {
    display: flex;
    align-items: center;
    position: relative;
    cursor: pointer;
    margin-right: 700px;
}

.main-icon {
    width: 30px;
    height: 30px;
    margin-right: 10px;
}

.wiseglobe-text {
    font-size: 18px;
    font-weight: bold;
    display: flex;
    align-items: center;
}

.wise {
    color: orangered;
    font-size: 20px;
    font-weight: bold;
}

.globe {
    color: white;
    font-size: 20px;
    font-weight: bold;
}

.logout-icon {
    position: fixed;
    top: 20px;
    right: 20px;
}

.logout-icon img {
    width: 30px;
    height: 30px;
    cursor: pointer;
}

.logout-icon:hover::after {
    content: "Logout";
    position: absolute;
    top: 60px; /* Below the button */
    left: 50%;
    transform: translateX(-50%);
    background-color: #000;
    color: #fff;
    padding: 5px 10px;
    font-size: 12px;
    border-radius: 5px;
    white-space: nowrap;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    z-index: 1000;
}

    </style>
</head>
<body>
<header>
        <!-- Back Button -->
        <div class="back-button" onclick="goBack()">
            <img src="photo/back.jpeg" alt="Back">
        </div>
        <!-- Title with Main Icon -->
        <div class="title-container">
            <img src="photo/main-icon.png" alt="Main Icon" class="main-icon">
            <div class="wiseglobe-text">
                <span class="wise">Travel</span><span class="globe">Planner</span>
            </div>
           
        </div>
    </header>
<div class="form-box">
    
    <h2>Edit Profile</h2>
    <form action="edit_profile.php?id1=<?php echo $id1; ?>" method="POST">
        <div class="form-group">
            <label>First Name</label>
            <input type="text" name="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>">
        </div>
        <div class="form-group">
            <label>Last Name</label>
            <input type="text" name="last_name" value="<?php echo htmlspecialchars($user['last_name']); ?>">
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>">
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" value="<?php echo htmlspecialchars($user['password']); ?>">
        </div>
        <button type="submit">Save</button>
    </form>
</div>
<footer>
        <p>&copy; 2024 All Rights Reserved</p>
    </footer>
    <script>
        function goBack() {
                    window.history.back();
                }
    </script>
</body>
</html>
