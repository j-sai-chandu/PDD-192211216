<?php
$conn = new mysqli('localhost', 'root', '', 'project');

// Check if the database connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get email and password from the form submission
$email = $_POST['email'];
$password = $_POST['password'];

// Query to verify the email and password
$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
$result = $conn->query($sql);

// Default error message for invalid credentials
$m = "Invalid credentials! Please enter the correct details.";

// Check if the query returned a matching user
if ($result->num_rows > 0) {
    // Fetch the user details
    $user = $result->fetch_assoc();
    $userId1 = $user['id1']; // Get the user's ID
    $haveSubscription = $user['have_subscription']; // Get the subscription status ('Yes' or 'No')

    // Redirect based on the subscription status
    if ($haveSubscription === 'Yes') {
        header("Location: mainS.php?id1=$userId1"); // Redirect to mainS.php with the user ID
    } else {
        header("Location: main.php?id1=$userId1"); // Redirect to main.php with the user ID
    }
    exit; // Stop further script execution after the redirect
} else {
    // Invalid credentials case: Show an alert and redirect to login page
    echo "<script type='text/javascript'>
        alert('$m');
        window.location.href = 'login.html';
    </script>";
}

// Close the database connection
$conn->close();
?>
